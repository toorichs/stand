#NOTES

Requirements -
• Magisk Alpha / KernelSU / Apatch [latest]³


Useful for ------------->
• SHAMIKO ( to hide magisk )

• TRICKY STORE ( adds all user app package names to target list, appending an exclamation mark in the end of each package name )

• LSPOSED ( disables lsposed traces & logs )

• ROM sign spoofing 

• Encryption spoofing 


# Credits:

Some functions in this project are built upon the excellent foundation laid by yervant7's https://github.com/yervant7 & ez-me's https://github.com/ez-me/ezme-nodebug project. While their original codebase was outdated, it served as a crucial starting point. I've updated it for compatibility with modern Android versions, and i extend my sincere thanks to @yervant7 & @ez-me for their foundational work.

# Note

• Disable the module before removing it otherwise you've to detete the /data/adb/shamiko/whitelist file
