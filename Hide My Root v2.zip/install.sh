# Magisk mount
SKIPMOUNT=false

# load post-fs-data script
POSTFSDATA=true

# TempDir Path
TMPDIR=/dev/tmp

# Installation Preview 2
print_modname() {
MODNAME=`grep_prop name $TMPDIR/module.prop`
MODVER=`grep_prop version $TMPDIR/module.prop`
DV=`grep_prop author $TMPDIR/module.prop`
Device=`getprop ro.product.device`
Model=`getprop ro.product.model`
Brand=`getprop ro.product.brand` 
Architecture=`getprop ro.product.cpu.abi`
SDK=`getprop ro.system.build.version.sdk`
Android=`getprop ro.system.build.version.release`
Type=`getprop ro.system.build.type`
Built=`getprop ro.system.build.date`
Time=$(date "+%d, %b - %H:%M %Z")

sleep 0.1
echo "-------------------------------------"
echo "Fetching module info..."
echo "-------------------------------------"
sleep 1.5
echo -e "- Author：\c"
echo "$DV"
sleep 0.5
echo -e "- Module：\c"
echo "$MODNAME"
sleep 0.5
echo -e "- Version：\c"
echo "$MODVER"
sleep 0.5
echo -e "- Provider：\c"
if [ "$BOOTMODE" ] && [ "$KSU" ]; then
ui_print "KernelSU app"
  sed -i "s/^des.*/description= [🦄 KernelSU is loaded] Enable ${MODNAME} /g" $MODPATH/module.prop
ui_print "- KernelSU：$KSU_KERNEL_VER_CODE (kernel) + $KSU_VER_CODE (ksud)"
  if [ "$(which magisk)" ]; then
 ui_print "==================================================="
 ui_print "! Multiple root implementation is NOT supported!"
    abort    "==================================================="
fi
elif [ "$BOOTMODE" ] && [ "$MAGISK_VER_CODE" ]; then
ui_print "Magisk app"
 sed -i "s/^des.*/description= [🪷 Magisk is loaded] Enable ${MODNAME} /g" $MODPATH/module.prop
ui_print " ☝️🤓 Use latest MAGISK ALPHA if"
ui_print "  ▶️Action button does not appear for you"
ui_print " "
sleep 1
else
echo "-------------------------------------"
ui_print "Installation from recovery is not supported"
ui_print "Please install from KernelSU or Magisk app"
abort "-------------------------------------"
fi
sleep 1
echo "-------------------------------------"
echo "Fetching device info..."
echo "-------------------------------------"
sleep 1.5
echo "- Brand：$Brand"
sleep 0.5
echo "- Device：$Device"
sleep 0.5
echo "- Model：$Model"
sleep 0.5
echo "- RAM：$(free | grep Mem | awk '{print $2}')"
sleep 0.5
echo "-------------------------------------"
echo "Fetching ROM info..."
echo "-------------------------------------"
sleep 1.5
echo "- Android：$Android"
sleep 0.5
echo -e "- Kernel：\c"
echo "$(uname -r)"
sleep 0.5
echo "- CPU：$Architecture"
sleep 0.5
echo "- SDK：$SDK"
sleep 0.5
echo "- Build Date：$Built"
sleep 0.5
echo "- Build Type：$Type"
sleep 1
echo "-------------------------------------"
echo "- Preparing $MODNAME!"
echo "-------------------------------------"
sleep 1.5
ui_print "- Flashing started at $Time !!"
sleep 1
}

# Check if target.txt exists
 if [ ! -f /data/adb/tricky_store/target.txt ]; then
ui_print "target.txt not found!"
ui_print "Please install tricky store module"
ui_print "if you need strong integrity,"
ui_print "else ignore this message."
ui_print " "
 fi

# Create the directory for target file if it doesn't exist
 mkdir -p /data/adb/tricky_store

# Remove T-Target module if exists
 ttarget="/data/adb/modules/Ttarget"
 if [ -d "$ttarget" ]; then
  rm -rf "$ttarget"
echo "- T-Target module removed."
# else
#echo ""
 fi
 
# Remove FBE ENABLER module if exists
 fbe="/data/adb/modules/FBE_Enabler"
 if [ -d "$fbe" ]; then
  rm -rf "$fbe"
echo "- FBE Enabler module removed."
# else
#echo ""
 fi 
 
# Remove Ching Chong Encryption module if exists
 china="/data/adb/modules/Camouflaged_data_encryption"
 if [ -d "$china" ]; then
  rm -rf "$china"
echo "- Encryption Enabler module removed."
# else
#echo ""
 fi  

# Detect Shamiko
shamiko="/data/adb/modules/zygisk_shamiko"
shamiko_repo="https://github.com/LSPosed/LSPosed.github.io/releases"

if [ ! -d "$shamiko" ]; then
echo "Please install the Zygisk Shamiko module to use the root hiding feature."
echo "You can download it from: $shamiko_repo"
#echo ""
 am start -a android.intent.action.VIEW -d "$shamiko_repo" >/dev/null 2>&1 &
else
echo "- Shamiko module detected.✅"
#echo ""
fi

# Directory where the script will be created.
HMR_DIR="/data/adb/modules_update/HideMyRoot"
ATN_DIR="/data/adb/modules/HideMyRoot"
mkdir $HMR_DIR

# Target text updater script
cat > "$HMR_DIR/action.sh" << EOF
#!/bin/sh
ATN_DIR="/data/adb/modules/HideMyRoot"
cd $ATN_DIR
chmod +x "$ATN_DIR/post-fs-data.sh"
exec "/$ATN_DIR/post-fs-data.sh"
echo "🪷"
sleep 2
exit 0
EOF

# Make executable
chmod +x "$HMR_DIR/action.sh"

# on_install function
 on_install() {
ui_print "- Processing module files..."
  if unzip -o "$ZIPFILE" 'system/*' -d "$MODPATH" >&2; then
ui_print "- Module files processed successfully."
  else
ui_print "ERROR: Failed to process module files. Check the ZIP file and permissions."
   exit 1
  fi
 }

# set_permissions function
set_permissions() {
  # Set recursive permissions first
  if ! set_perm_recursive "$MODPATH" 0 0 0755 0644; then
    echo "ERROR: Failed to set recursive permissions. Check ownership and permissions of $MODPATH."
    exit 1
  fi

  # Now, set the specific permission for logd
  if ! set_perm "$MODPATH/system/bin/logd" 0 0 0550; then
    echo "ERROR: Failed to set permissions for $MODPATH/system/bin/logd."
    exit 1  
  fi

  echo "- Permissions set successfully."
}

sleep 1.5
 
# Installation Preview 1
ui_print "▬▬▬.◙.▬▬▬"
ui_print "═▂▄▄▓▄▄▂"
ui_print "◢◤ █▀▀████▄▄▄▄◢◤"
ui_print "█▄ █ █▄ ███▀▀▀▀▀▀▀╬"
ui_print "◥█████◤"
ui_print "══╩══╩═"
ui_print "╬═╬"
ui_print "╬═╬ just dropped down to say"
ui_print "╬═╬"
ui_print "╬═╬"
ui_print "╬═╬☻/ Avoid using unnecessary modules"
ui_print "╬═╬/▌   if you want to hide root "
ui_print "╬═╬/ \ "
sleep 1

# End of file