#!/system/bin/sh
MCTRL="${0%/*}"; WHITELIST="/data/adb/shamiko/whitelist"
while true; do
 if [ ! -e "${MCTRL}/disable" ] && [ ! -e "${MCTRL}/remove" ]; then
  [ ! -f "$WHITELIST" ] && touch "$WHITELIST" && echo "Whitelist Mode Activated.✅"
 else
  [ -f "$WHITELIST" ] && rm "$WHITELIST" && echo "Blacklist Mode Activated.❌"
 fi
 sleep 4
done