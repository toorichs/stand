#!/system/bin/sh

# Target file path
target_file="/data/adb/tricky_store/target.txt"
rm -rf $target_file # because it was repeating the package names

# Check if the target file exists, create it if it doesn't
if [ ! -f "$target_file" ]; then
 touch "$target_file"
 echo "✦ Target file '$target_file' created."
fi

# Add the default package names to the target file
echo "✦ Adding default package names:"
echo "com.google.android.gms" >> "$target_file"
echo "io.github.vvb2060.keyattestation" >> "$target_file"
echo "io.github.vvb2060.mahoshojo" >> "$target_file"
echo "icu.nullptr.nativetest" >> "$target_file"
sleep 1

# Get all third-party app package names and add them to the target.txt file, appending an exclamation ! mark.
echo "✦ Retrieving all installed third-party packages:"
pm list packages -3 | cut -d ":" -f 2 | sed 's/$/!/' >> "$target_file"
sleep 2

# Display the result
echo "✦ Here are the updated packages in target list"
sleep 1
echo " "
cat "$target_file"
echo " "
echo "--------------------------------------------------"
echo "✦✦ Target list has been updated ✦✦"
echo "--------------------------------------------------"
echo " "
sleep 5
exit 0