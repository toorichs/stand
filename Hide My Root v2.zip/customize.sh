#!/system/bin/sh
MODPATH="/data/adb/modules/HideMyRoot"
TMP_FILE="/tmp/hidemyroot_temp_props"

# Create temporary file and directory
mkdir -p "$MODPATH" || { echo "Error creating directory '$MODPATH': $?" >&2; exit 1; }
touch "$TMP_FILE" || { echo "Error creating temporary file '$TMP_FILE': $?" >&2; exit 1; }

# Function to safely process properties
process_prop() {
  local prop_name="$1"
  local prop_value="$2"

  if [[ -z "$prop_value" ]]; then
      return
  fi

  prop_value=$(printf "%q" "$prop_value")

  echo "${prop_name}=${prop_value}" >> "$TMP_FILE"
}

# Function to set properties only if different
resetprop_if_diff() {
    local prop_name="$1"
    local prop_value="$2"
    current_value=$(getprop "$prop_name")
    if [[ -z "$current_value" || "$current_value" != "$prop_value" ]]; then
        resetprop "$prop_name" "$prop_value"
    fi
}

# Properties to remove
lineage_props=(
    "ro.lineage.build.version"
    "ro.lineage.build.version.plat.rev"
    "ro.lineage.build.version.plat.sdk"
    "ro.lineage.device"
    "ro.lineage.display.version"
    "ro.lineage.legal.url"
    "ro.lineage.releasetype"
    "ro.lineage.system.build.fingerprint"
    "ro.lineage.version"
)

# Properties to conditionally set
special_props=(
    "ro.boot.flash.locked=1"
    "ro.boot.vbmeta.device_state=locked"
    "ro.boot.verifiedbootstate=green"
    "ro.boot.veritymode=enforcing"
    "vendor.boot.verifiedbootstate=green"
    "vendor.boot.vbmeta.device_state=locked"
)


# Wait for boot completion
while [ "$(getprop sys.boot_completed)" != 1 ]; do
    sleep 1
done

#Initial Property Modification
for prop in "${lineage_props[@]}"; do
    if ! resetprop --delete "$prop" &> /dev/null; then
        echo "Warning: Failed to delete property '$prop': $?" >&2
    fi
done

# Extract and process properties
getprop | awk -F'[: ]' '{ if ($1 ~ /userdebug|test-keys|lineage_/) print $1, $NF }' | while IFS=" " read -r key value; do
    process_prop "$key" "$value"
done

# Replace unwanted strings
while IFS='=' read -r key value; do
  case "$key" in
    userdebug) process_prop "user" "user";;
    test-keys) process_prop "ro.build.keys" "release-keys";;
    lineage_*) process_prop "${key#lineage_}" "$value";;
    *) process_prop "$key" "$value";;
  esac
done < "$TMP_FILE"

# Sort properties and create system.prop
sort -u "$TMP_FILE" > "$MODPATH/system.prop"
rm "$TMP_FILE"

# Set properties initially
if ! resetprop -n --file "$MODPATH/system.prop"; then
  echo "Error setting properties. Check log for details." >&2
  exit 1
fi

# Set special properties only if different
for prop in "${special_props[@]}"; do
    prop_name="${prop%%=*}"
    prop_value="${prop#*=}"
    resetprop_if_diff "$prop_name" "$prop_value"
done


echo "Properties set successfully."

exit 0
